package employeemanagemntsystem;

public class MenuStatistics implements Menu {

    @Override
    public String findEmployeeByName(String nameToFind) {
        return null;
    }

    @Override
    public int findEmployeeById(int idToFind) {
        return 0;
    }

    @Override
    public Department findEmployeeByDepartment(Department departmentToFind) {
        return null;
    }
    
}