package employeemanagemntsystem;

public enum Gender {
    MALE, FEMALE, UNSPECIFIED;
}
