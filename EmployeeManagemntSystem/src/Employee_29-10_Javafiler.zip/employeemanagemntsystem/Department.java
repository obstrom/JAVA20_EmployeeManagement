package employeemanagemntsystem;

public enum Department {
    IT, ECONOMY, MARKETING, HR, MANAGEMENT;
}
