package employeemanagemntsystem;

public enum EmployeeCategory {
    MANAGER, PROGRAMMER, SECRETARY, TECHNICIAN;
}