package employeemanagemntsystem;

public class MenuEmployeeSystem implements Menu {

    /*public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDepartement() {
        return departement;
    }

    public void setDepartement(String departement) {
        this.departement = departement;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }*/

    @Override
    public String findEmployeeByName(String nameToFind) {
        return null;
    }

    @Override
    public int findEmployeeById(int idToFind) {
        return 0;
    }

    @Override
    public Department findEmployeeByDepartment(Department departmentToFind) {
        return null;
    }
}
